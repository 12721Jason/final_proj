from ultralytics import YOLO

def pt_to_onnx(pt_path, opset_version=16):
    model = YOLO(pt_path)
    export_path = model.export(format='onnx', opset=11, imgsz=640, verbose=True)
    print(f"模型已成功导出为 ONNX 格式")

if __name__ == "__main__":
    pt_model_path = "best.pt"
    pt_to_onnx(pt_model_path)
