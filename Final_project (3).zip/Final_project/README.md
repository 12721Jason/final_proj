Final_project [YOLOv8-main]
│
├── pytorch-neural-style-transfer/     # 神经风格迁移模块
│   ├── content-images/                # 内容图像目录
│   ├── models/                        # 保存模型目录
│   ├── style-images/                  # 风格图像目录
│   ├── utils/                         # 工具函数
│   │   ├── __init__.py
│   │   ├── neural_style_transfer.py  # 风格迁移主函数
│   │   └── reconstruct_image_from_representation.py
│   └── README.md                      # 风格迁移模块说明文档，从github上下载并进行优化的模型
│
├── styletransfer_output/             # 风格迁移结果输出目录
│
├── ui/                               
│   └── myWindow.ui                   # PyQt5 界面设计文件
│
├── ultralytics/                      # YOLOv8推理模块与界面整合
│   ├── convert.py                    # 格式转换（pt模型转ONNX模型）
│   ├── example.jpg                   # 示例图像1
│   ├── example2.png                  # 示例图像2
│   ├── infer.py                      # 推理逻辑
│   ├── main.py                       # 主运行入口
│   ├── myWindow.py                   # PyQt5 主窗口逻辑
│   ├── noise.png                     # 有噪声示例图像
│   └── op.png                        # 运算模板图像
│
│
├── requirements.txt                 # 项目所需Python依赖
└── README.md                        # 主项目说明文档