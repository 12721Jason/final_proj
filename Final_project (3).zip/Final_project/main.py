import os  # 用于文件路径拼接、检查与目录操作
import sys  # 用于控制程序的退出，调用命令行操作
import time # 提供时间戳
import subprocess  # 用于调用外部脚本
import qimage2ndarray   # 支持 QImage 与 numpy.ndarray 之间的转换
import matplotlib.pyplot as plt  # 用于图像结果的可视化展示
import traceback  # 捕获并打印详细异常信息，便于调试
# PyQt5 图形界面与图像处理模块
from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt, QTimer, QDateTime, QThread, pyqtSignal, QMutex
from PyQt5.QtGui import QPixmap, QImage, qRed, qGreen, qBlue
from PyQt5.QtWidgets import QFileDialog, QMainWindow, QMessageBox
# 多线程通信与队列支持
from queue import Queue  # 跨线程传递数据，如摄像头帧队列
# 项目内模块导入
from myWindow import Ui_Form  # QtDesigner 生成的界面类，UI主窗口
from infer import *  # 推理模块，定义了YOLOv8模型加载与ONNX推理相关功能

# 视频帧队列，用于线程间传递图像帧
video_stream_queue = Queue()

def get_args():
    """
    解析命令行参数，用于指定模型路径、置信度阈值和NMS阈值。同时根据当前系统是否支持CUDA，自动选择对应的onnxruntime版本。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, default='yolov8s.onnx', help='ONNX模型路径')
    parser.add_argument('--conf-thres', type=float, default=0.3, help='置信度阈值')
    parser.add_argument('--iou-thres', type=float, default=0.45, help='NMS IoU阈值')
    args = parser.parse_args()
    check_requirements('onnxruntime-gpu' if torch.cuda.is_available() else 'onnxruntime')
    return args


class CameraCaptureThread(QThread):
    """
    摄像头采集线程，持续读取摄像头图像帧并转换为RGB格式
    """
    image_signal = pyqtSignal(object)  # 定义图像信号，传递RGB图像

    def __init__(self):
        super().__init__()
        self.mutex = QMutex()          # 设定线程锁，保护共享资源
        self.is_paused = False         # 暂停标志位
        self.current_frame = None

    def run(self):
        global cap
        while True:
            self.mutex.lock()
            time.sleep(0.001)
            ret, frame = cap.read()
            if not ret:
                self.mutex.unlock()
                continue
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # 图像从BGR格式转RGB格式
            self.current_frame = frame_rgb
            self.image_signal.emit(self.current_frame)
            self.mutex.unlock()


class DetectionThread(QThread):
    """
    目标检测线程，用于从摄像头读取图像帧，执行YOLOv8推理检测，并将结果图像通过信号发送。这里支持视频流处理，将视频流分割成图像帧后送入共享队列用于后续处理
    """

    detection_signal = pyqtSignal(object)  # 检测结果信号，传递检测后RGB图像

    def __init__(self):
        super().__init__()
        self.mutex = QMutex()
        self.is_paused = False
        self.current_frame = None
        self.video_flag = 0  # 检测是否是视频流标志

    def run(self):
        global cap
        while True:
            self.mutex.lock()
            time.sleep(0.001)
            ret, frame = cap.read()
            if not ret:
                self.mutex.unlock()
                continue
            args = get_args()
            detector = Yolov8(args.model, frame, args.conf_thres, args.iou_thres)  # 初始化模型
            detected_frame = detector.main()  # 执行推理检测
            frame_rgb = cv2.cvtColor(detected_frame, cv2.COLOR_BGR2RGB)
            if self.video_flag == 0:
                video_stream_queue.put(frame_rgb)  # 视频帧加入共享队列
            self.current_frame = frame_rgb
            self.detection_signal.emit(self.current_frame)
            self.mutex.unlock()


def CvimgtoQtimg(cv_img):
    """
    OpenCV的BGR图像转为PyQt的QImage图像，用于可视化界面显示。
    """
    QtImgBuf = cv2.cvtColor(cv_img, cv2.COLOR_BGR2BGRA)
    qt_img = QImage(QtImgBuf.data, QtImgBuf.shape[1], QtImgBuf.shape[0], QImage.Format_RGB32)
    return qt_img

class myWindow(QMainWindow, Ui_Form):
    """
    主界面类，负责绑定功能函数和可视化界面按钮
    """

    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.mode_flag = 0
        self.pic_after = self.Picafterlabel
        self.pic_before = self.Picbeforelabel
        self.OpenimgBtn.clicked.connect(self.Open_Image)
        self.CameraBtn.clicked.connect(self.Open_Camera)
        self.EmtiondetectBtn.clicked.connect(self.Start_Detect)
        self.SaveimgBtn.clicked.connect(self.Save_Image)
        self.GrayscaleBtn.clicked.connect(self.Grayscale)
        self.BinarizationBtn.clicked.connect(self.Binarization)
        self.HistogramBtn.clicked.connect(self.Histogram)
        self.EqualizeBtn.clicked.connect(self.Equalize)
        self.NormalizationBtn.clicked.connect(self.Normalization)
        self.ErosionBtn.clicked.connect(self.Erosion)
        self.DilationBtn.clicked.connect(self.Dilation)
        self.CloseopBtn.clicked.connect(self.Closeop)
        self.OpenopBtn.clicked.connect(self.Openop)
        self.CloseopBtn.clicked.connect(self.Closeop)
        self.Openimg2btn.clicked.connect(self.Openanother)
        self.AddBtn.clicked.connect(self.Add)
        self.SubBtn.clicked.connect(self.Sub)
        self.MulBtn.clicked.connect(self.Mul)
        self.NoiseAddBtn.clicked.connect(self.NoiseAdd)
        self.FrequencyFilterBtn.clicked.connect(self.FrequencyFilter)
        self.MeanFilterBtn.clicked.connect(self.MeanFilter)
        self.MidFilterBtn.clicked.connect(self.MidFilter)
        self.RobertsBtn.clicked.connect(self.Roberts)
        self.PrewittBtn.clicked.connect(self.Prewitt)
        self.LoGBtn.clicked.connect(self.LoG)
        self.LaplacianBtn.clicked.connect(self.Laplacian)
        self.CannyBtn.clicked.connect(self.Canny)
        self.LinedetectBtn.clicked.connect(self.Linedetect)
        self.IdealHighBtn.clicked.connect(self.IdealHigh)
        self.ButterworthHighBtn.clicked.connect(self.ButterworthHigh)
        self.GaussianHighBtn.clicked.connect(self.GaussianHigh)
        self.SpatialSharpeningBtn.clicked.connect(self.SpatialSharpening)
        self.IdealLowBtn.clicked.connect(self.IdealLow)
        self.ButterworthLowBtn.clicked.connect(self.ButterworthLow)
        self.GaussianLowBtn.clicked.connect(self.GaussianLow)
        self.Openimg3Btn.clicked.connect(self.Openthree)
        self.StyleBtn.clicked.connect(self.Style_transfer)
        self.Show_Time()

    def Open_Image(self):
        """ 打开第一张图片文件并加载显示其信息 """
        self.openfile_name = QFileDialog.getOpenFileName(self, '选择文件', '', "Image Files (*.png *.jpg *.bmp)")[0]
        if not self.openfile_name:
            return  # 如果用户未选择文件，直接返回

        try:
            # 使用Qt方式加载图像用于显示
            self.pix_before = QPixmap(self.openfile_name)
            if self.pix_before.isNull():
                raise ValueError("无法加载图片文件")

            # 用OpenCV方式读取图像，便于后续处理
            self.image = cv2.imread(self.openfile_name)

            # 显示图像的基本信息
            self.Label_H.setText(str(self.image.shape[0]))  # 图像高度
            self.Label_W.setText(str(self.image.shape[1]))  # 图像宽度
            self.Label_Channel.setText(str(self.image.shape[2]))  # 通道数
            self.Label_Type.setText(str(self.image.dtype))  # 数据类型

            # 将图片自适应缩放并显示图片
            self.ResizeImage(self.pic_before, self.pix_before)

        except Exception as e:
            traceback.print_exc()
            QMessageBox.critical(self, "错误", f"加载图片文件时出错: {e}")

    def Openanother(self):
        """ 打开第二张图片文件并加载显示信息"""
        self.openfile_name2 = QFileDialog.getOpenFileName(self, '选择文件', '', "Image Files (*.png *.jpg *.bmp)")[0]
        if not self.openfile_name2:
            return

        try:
            self.pix_before = QPixmap(self.openfile_name2)
            if self.pix_before.isNull():
                raise ValueError("无法加载图片文件")

            self.image2 = cv2.imread(self.openfile_name2)

            self.Label_H.setText(str(self.image2.shape[0]))
            self.Label_W.setText(str(self.image2.shape[1]))
            self.Label_Channel.setText(str(self.image2.shape[2]))
            self.Label_Type.setText(str(self.image2.dtype))

            self.ResizeImage(self.pic_before, self.pix_before)

        except Exception as e:
            traceback.print_exc()
            QMessageBox.critical(self, "错误", f"加载图片文件时出错: {e}")

    def Openthree(self):
        """ 打开第三张图片文件，仅加载不显示，用于导入风格图片 """
        self.openfile_name3 = QFileDialog.getOpenFileName(self, '选择文件', '', "Image Files (*.png *.jpg *.bmp)")[0]
        if not self.openfile_name3:
            return

        try:
            if self.pix_before.isNull():
                raise ValueError("无法加载图片文件")
            self.image3 = cv2.imread(self.openfile_name3)
        except Exception as e:
            traceback.print_exc()
            QMessageBox.critical(self, "错误", f"加载图片文件时出错: {e}")

    def Open_Camera(self):
        """ 启动摄像头并创建线程进行实时采集与检测 """
        self.mode_flag = 1  # 切换为摄像头模式
        self.detection_thread = DetectionThread()  # 启动检测线程
        self.detection_thread.detection_signal.connect(self.Update_Detection_Image)

        self.capture_thread = CameraCaptureThread()  # 启动采集线程
        self.capture_thread.image_signal.connect(self.Update_Capture_Image)
        self.capture_thread.start()

    def Update_Capture_Image(self, img):
        """ 显示摄像头采集的原始图像 """
        qimg = qimage2ndarray.array2qimage(img)
        self.Videolabel.setPixmap(QPixmap(qimg))
        self.Videolabel.setScaledContents(True)
        self.Videolabel.show()

    def Update_Detection_Image(self, img):
        """ 显示摄像头图像的检测结果图 """
        qimg = qimage2ndarray.array2qimage(img)
        self.Emotionlabel.setPixmap(QPixmap(qimg))
        self.Emotionlabel.setScaledContents(True)
        self.Emotionlabel.show()

    def Start_Detect(self):
        """ 开始进行实时监测 """
        if self.mode_flag == 0:  # 图片检测
            img = self.image
            args = get_args()
            detector = Yolov8(args.model, img, args.conf_thres, args.iou_thres)
            result_img = detector.main()  # 进行检测
            self.result = result_img
            qt_img = CvimgtoQtimg(result_img)  # 转换为Qt图像
            self.pix_after = QPixmap.fromImage(qt_img)
            self.ResizeImage(self.pic_after, self.pix_after)
        else:
            # 摄像头检测通过线程运行
            self.detection_thread.start()

    def Show_Current_Time(self, time_label):
        """ 获取当前系统时间并显示到标签上 """
        now = QDateTime.currentDateTime()
        current_time_str = now.toString('yyyy-MM-dd hh:mm:ss dddd')
        time_label.setText(current_time_str)
        self.current_time_str = current_time_str  # 供后续使用

    def Show_Time(self):
        """ 启动定时器，每隔一段时间更新时间 """
        self.timer = QTimer()
        self.timer.timeout.connect(lambda: self.Show_Current_Time(self.label_2))
        self.timer.start()

    def Save_Image(self):
        """ 将处理结果图像保存至本地文件 """
        if self.pix_after.isNull():
            QMessageBox.about(self, '保存失败', '没有已经处理完成的图片')
            return
        SaveName = QFileDialog.getSaveFileName(self, '选择文件', '', "Image Files (*.png *.jpg *.bmp)")[0]
        if not SaveName:
            return
        if not (SaveName.lower().endswith('.png') or SaveName.lower().endswith('.jpg') or SaveName.lower().endswith(
                '.bmp')):
            SaveName += '.png'

        try:
            result = False
            if hasattr(self, "result") and isinstance(self.result, np.ndarray):
                save_img = self.result
                print(f"[DEBUG] result.shape: {save_img.shape}, dtype: {save_img.dtype}")
                # 数据类型转换为uint8
                if save_img.dtype != np.uint8:
                    save_img = np.clip(save_img, 0, 1) if save_img.max() <= 1.0 else np.clip(save_img, 0, 255)
                    save_img = (save_img * 255).astype(np.uint8) if save_img.max() <= 1.0 else save_img.astype(np.uint8)
                # RGB转BGR保存
                if save_img.ndim == 3 and save_img.shape[2] == 3:
                    save_img = cv2.cvtColor(save_img, cv2.COLOR_RGB2BGR)
                result = cv2.imwrite(SaveName, save_img)
            else:
                print(f"[DEBUG] QPixmap size: {self.pix_after.size()}")
                result = self.pix_after.save(SaveName)
            if result:
                QMessageBox.about(self, '保存成功', f'图片已保存至：\n{SaveName}')
            else:
                QMessageBox.about(self, '保存失败', '保存失败，请检查路径或图像内容')

        except Exception as e:
            traceback.print_exc()
            QMessageBox.critical(self, '异常', f"保存出错: {e}")

    def Check(self):
        """ 检查图片是否有效 """
        if self.pix_before.isNull():
            QMessageBox.about(self, '操作失败', '请先导入图片')
            return True
        img = self.image
        if img is None:
            QMessageBox.about(self, '操作失败', '无法读取图片')
            return True
        return False

    def ResizeImage(self, label, pixmap):
        """ 对图片进行自适应缩放并进行展示 """
        if pixmap:
            label.setPixmap(pixmap.scaled(label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def Grayscale(self):
        """ 图像灰度化处理 """
        if self.Check():  # 检查是否有图像载入
            return
        img = self.image  # 获取原始图像
        grayImg = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转换为灰度图
        qt_img = CvimgtoQtimg(grayImg)  # 转换为Qt图像格式
        self.pix_after = QPixmap.fromImage(qt_img)  # 创建QPixmap对象
        self.ResizeImage(self.pic_after, self.pix_after)  # 显示图像

    def Binarization(self):
        """ 对图像进行二值化处理，分隔值为127 """
        if self.Check():
            return
        try:
            img = self.image
            grayImg = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 灰度化
            _, binary_img = cv2.threshold(grayImg, 127, 255, cv2.THRESH_BINARY)  # 固定分隔值并进行二值化
            qt_img = CvimgtoQtimg(binary_img)
            self.pix_after = QPixmap.fromImage(qt_img)
            self.ResizeImage(self.pic_after, self.pix_after)
        except Exception as e:
            traceback.print_exc()

    def Histogram(self):
        """ 显示图像灰度直方图 """
        if self.Check():
            return
        img = self.image
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转换为灰度图
        hist = cv2.calcHist([gray], [0], None, [256], [0, 255])  # 计算灰度直方图
        plt.plot(hist)  # 用matplotlib画出直方图
        plt.savefig('img.jpg')
        plt.close()  # 关闭绘图窗口
        self.pix_after = QPixmap('img.jpg')  # 用QPixmap加载保存的图像，将直方图显示出来
        self.ResizeImage(self.pic_after, self.pix_after)
        os.remove('img.jpg')  # 删除临时文件

    def Equalize(self):
        """ 图像直方图均衡化，用于增强图片的对比度 """
        if self.Check():
            return
        img = self.image
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转换为灰度图
        equalized_img = cv2.equalizeHist(gray)  # 进行直方图均衡化
        qt_img = CvimgtoQtimg(equalized_img)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Normalization(self):
        """ 图像直方图正规化，将其归一至0 - 255 """
        if self.Check():
            return
        img = self.image
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转换为灰度图
        img_normalized = cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX)  # 最小最大值归一化
        qt_img = CvimgtoQtimg(img_normalized)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Median(self):
        """ 中值滤波，用于去除椒盐噪声 """
        if self.Check():
            return
        img = self.image
        median_filtered = cv2.medianBlur(img, 5)  # 使用5x5的滤波窗口
        qt_img = CvimgtoQtimg(median_filtered)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Erosion(self):
        """ 图像腐蚀操作，缩小白色区域 """
        if self.Check():
            return
        img = self.image
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转为灰度图
        _, img_binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)  # 对图片进行二值化
        kernel = np.ones((3, 3), np.uint8)  # 定义3x3腐蚀核
        img_eroded = cv2.erode(img_binary, kernel, iterations=1)
        qt_img = CvimgtoQtimg(img_eroded)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Dilation(self):
        """ 图像膨胀操作，扩展白色区域 """
        if self.Check():
            return
        img = self.image
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转为灰度图
        _, img_binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)  # 对图片进行二值化
        kernel = np.ones((3, 3), np.uint8)  # 3x3膨胀核
        img_dilated = cv2.dilate(img_binary, kernel, iterations=1)
        qt_img = CvimgtoQtimg(img_dilated)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Openop(self):
        """ 图像开运算"""
        if self.Check():
            return
        img = self.image
        img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转灰度图
        ret, img_binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)  # 对图片进行二值化
        kernel = np.ones((3, 3), np.uint8)  # 3x3卷积核
        img_opened = cv2.morphologyEx(img_binary, cv2.MORPH_OPEN, kernel)  # 开运算
        qt_img = CvimgtoQtimg(img_opened)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Closeop(self):
        """ 图像闭运算（填补小的黑洞）"""
        if self.Check():
            return
        img = self.image
        img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) # 转灰度图
        ret, img_binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY) # 对图片进行二值化
        kernel = np.ones((3, 3), np.uint8)
        img_closed = cv2.morphologyEx(img_binary, cv2.MORPH_CLOSE, kernel) # 闭运算
        qt_img = CvimgtoQtimg(img_closed)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def NoiseAdd(self, amount=0.03):
        """ 添加椒盐噪声 """
        if self.Check():
            return

        img = self.image
        img_gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if len(img.shape) == 3 else img
        row, col = img_gray.shape
        num_salt = int(amount * row * col / 2)
        num_pepper = int(amount * row * col / 2)
        noisy_img = img_gray.copy()
        # 添加盐噪声
        salt_coords = [np.random.randint(0, i, num_salt) for i in noisy_img.shape]
        noisy_img[salt_coords[0], salt_coords[1]] = 255
        # 添加椒噪声
        pepper_coords = [np.random.randint(0, i, num_pepper) for i in noisy_img.shape]
        noisy_img[pepper_coords[0], pepper_coords[1]] = 0
        # 直方图均衡化增强对比度
        img_enhanced = cv2.equalizeHist(noisy_img)
        qt_img = CvimgtoQtimg(img_enhanced)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def FrequencyFilter(self):
        """ 频域高斯高通滤波器 """
        if self.Check():
            return
        img = self.image
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if len(img.shape) == 3 else img
        cutoff_radius = 30
        height, width = gray.shape
        center_u, center_v = height // 2, width // 2
        fft_image = np.fft.fft2(gray)
        fft_shifted = np.fft.fftshift(fft_image)
        u, v = np.meshgrid(np.arange(width), np.arange(height))
        du = u - center_v
        dv = v - center_u
        distance = np.sqrt(du ** 2 + dv ** 2)
        # 构建高斯高通掩膜
        gaussian_highpass = 1 - np.exp(-(distance ** 2) / (2 * (cutoff_radius ** 2)))
        filtered = fft_shifted * gaussian_highpass
        inverse_shifted = np.fft.ifftshift(filtered)
        img_filtered = np.fft.ifft2(inverse_shifted)
        img_result = np.abs(img_filtered)
        img_result = np.uint8(np.clip(img_result, 0, 255))

        qt_img = CvimgtoQtimg(img_result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def MidFilter(self):
        """ 中值滤波器：效果最好"""
        if self.Check():
            return
        img = self.image
        img_gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if len(img.shape) == 3 else img
        # 核尺寸为5*5
        img_filtered = cv2.medianBlur(img_gray, 5)
        qt_img = CvimgtoQtimg(img_filtered)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def MeanFilter(self):
        """ 均值滤波"""
        if self.Check():
            return
        img = self.image
        img_gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if len(img.shape) == 3 else img
        img_filtered = cv2.blur(img_gray, (5, 5))
        qt_img = CvimgtoQtimg(img_filtered)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Add(self):
        """ 图像加法操作 """
        if self.Check():
            return
        img1 = self.image.copy()
        img2 = self.image2.copy()
        if img2 is None:
            QMessageBox.critical(self, "错误", "无法读取第二张图片")
            return
        h = min(img1.shape[0], img2.shape[0])
        w = min(img1.shape[1], img2.shape[1])
        img1 = cv2.resize(img1, (w, h))
        img2 = cv2.resize(img2, (w, h))
        result_img = cv2.add(img1, img2)  # 进行加法
        self.result = cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB)
        qt_img = CvimgtoQtimg(self.result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Sub(self):
        """ 图像减法操作 """
        if self.Check():
            return
        img1 = self.image.copy()
        img2 = self.image2.copy()
        if img2 is None:
            QMessageBox.critical(self, "错误", "无法读取第二张图片")
            return
        h = min(img1.shape[0], img2.shape[0])
        w = min(img1.shape[1], img2.shape[1])
        img1 = cv2.resize(img1, (w, h))
        img2 = cv2.resize(img2, (w, h))
        result_img = cv2.subtract(img1, img2) # 进行减法
        self.result = cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB)
        qt_img = CvimgtoQtimg(self.result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Mul(self):
        """ 图像乘法操作 """
        if self.Check():
            return
        img1 = self.image.copy()
        img2 = self.image2.copy()
        if img2 is None:
            QMessageBox.critical(self, "错误", "无法读取第二张图片")
            return
        h = min(img1.shape[0], img2.shape[0])
        w = min(img1.shape[1], img2.shape[1])
        img1 = cv2.resize(img1, (w, h))
        img2 = cv2.resize(img2, (w, h))
        img1_f = img1.astype(np.float32) / 255.0
        img2_f = img2.astype(np.float32) / 255.0
        multiplied = img1_f * img2_f  # 对图片进行归一化后进行乘法操作
        result_img = np.uint8(multiplied * 255)
        self.result = cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB)
        qt_img = CvimgtoQtimg(self.result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Roberts(self):
        """ Roberts边缘检测算子：通过简单的对角线差分检测图像边缘 """
        if self.Check():  # 检查图像是否加载
            return
        img = self.image
        img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转为灰度图像，便于处理
        ret, img_binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)  # 固定阈值二值化
        # 定义 Roberts 算子核：分别处理两个对角方向
        kernelx_Robert = np.array([[-1, 0], [0, 1]], dtype=int)
        kernely_Robert = np.array([[0, -1], [1, 0]], dtype=int)
        # 使用滤波器卷积计算梯度
        x_Robert = cv2.filter2D(img_binary, cv2.CV_16S, kernelx_Robert)
        y_Robert = cv2.filter2D(img_binary, cv2.CV_16S, kernely_Robert)
        absX_Robert = cv2.convertScaleAbs(x_Robert)
        absY_Robert = cv2.convertScaleAbs(y_Robert)
        # 合成两个方向的梯度图
        qt_img = CvimgtoQtimg(cv2.addWeighted(absX_Robert, 0.5, absY_Robert, 0.5, 0))
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Prewitt(self):
        """ Prewitt边缘检测算子 """
        if self.Check():
            return
        img = self.image
        img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转为灰度图
        ret, img_binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)  # 二值化处理
        # 定义 Prewitt 水平方向和垂直方向的卷积核
        kernelx_Prewitt = np.array([[1, 1, 1], [0, 0, 0], [-1, -1, -1]], dtype=int)
        kernely_Prewitt = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]], dtype=int)
        # 卷积得到 x 和 y 方向的梯度图
        x_Prewitt = cv2.filter2D(img_binary, -1, kernelx_Prewitt)
        y_Prewitt = cv2.filter2D(img_binary, -1, kernely_Prewitt)
        absX_Prewitt = cv2.convertScaleAbs(x_Prewitt)
        absY_Prewitt = cv2.convertScaleAbs(y_Prewitt)
        # 合成最终图像
        qt_img = CvimgtoQtimg(cv2.addWeighted(absX_Prewitt, 0.5, absY_Prewitt, 0.5, 0))
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def LoG(self):
        """ LoG边缘检测：先进行高斯滤波再拉普拉斯运算 """
        if self.Check():
            return
        img = self.image
        img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转灰度图
        ret, img_binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)  # 二值化处理

        # 定义 Laplacian of Gaussian滤波器大小为5x5
        kernelLoG = np.array([
            [0, 0, -1, 0, 0],
            [0, -1, -2, -1, 0],
            [-1, -2, 16, -2, -1],
            [0, -1, -2, -1, 0],
            [0, 0, -1, 0, 0]
        ], dtype=int)
        # 使用卷积进行边缘检测
        LoG_result = cv2.filter2D(img_binary, -1, kernelLoG)
        absLoG = cv2.convertScaleAbs(LoG_result)
        qt_img = CvimgtoQtimg(absLoG)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Laplacian(self):
        """ Laplacian边缘检测算子 """
        if self.Check():
            return
        img = self.image
        img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转灰度图
        ret, img_binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)  # 对图像进行二值化二值化
        # 使用 OpenCV 内置的 Laplacian 边缘检测器
        laplacian = cv2.Laplacian(img_binary, cv2.CV_64F)
        absLaplacian = cv2.convertScaleAbs(laplacian)
        qt_img = CvimgtoQtimg(absLaplacian)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Canny(self):
        """ 使用 Canny 算子进行边缘检测 """
        if self.Check():
            return
        img = self.image
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # 转为灰度图
        img_blur_canny = cv2.GaussianBlur(img_gray, (7, 7), 1, 1)  # 先进行高斯模糊
        qt_img = CvimgtoQtimg(cv2.Canny(img_blur_canny, 50, 150))  # 再应用Canny边缘检测
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Linedetect(self):
        """ 使用霍夫变换检测图像中的直线 """
        if self.Check():
            return
        img = self.image.copy()
        img_gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)  # 转灰度图
        blurred = cv2.GaussianBlur(img_gray, (5, 5), 0)
        edges = cv2.Canny(blurred, 30, 100, apertureSize=3)  # 先进行边缘检测
        lines = cv2.HoughLinesP(edges, rho=1, theta=np.pi / 180, threshold=50, minLineLength=30, maxLineGap=20)
        img_with_lines = img.copy()
        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                cv2.line(img_with_lines, (x1, y1), (x2, y2), (0, 255, 0), 2)
        else:
            QMessageBox.information(self, "提示", "没有检测到明显直线")
        qt_img = CvimgtoQtimg(img_with_lines)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def IdealLow(self):
        """ 理想低通滤波器：保留低频信息，去除高频细节，实现图像平滑 """
        if self.Check():
            return
        gray = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        fft_image = np.fft.fft2(gray)  # 傅里叶变换
        fft_shifted = np.fft.fftshift(fft_image)  # 中心化
        height, width = gray.shape
        center_u, center_v = height // 2, width // 2
        cutoff_radius = 50
        # 构建理想低通掩膜
        ideal_mask = np.zeros((height, width), np.uint8)
        ideal_mask[center_u - cutoff_radius:center_u + cutoff_radius,
        center_v - cutoff_radius:center_v + cutoff_radius] = 1
        filtered = fft_shifted * ideal_mask  # 频域滤波
        inverse_shifted = np.fft.ifftshift(filtered)
        img_filtered = np.fft.ifft2(inverse_shifted)
        img_result = np.abs(img_filtered)
        img_result = np.uint8(np.clip(img_result, 0, 255))

        qt_img = CvimgtoQtimg(img_result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def ButterworthLow(self):
        """ 巴特沃斯低通滤波器 """
        if self.Check():
            return
        gray = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        height, width = gray.shape
        cutoff_radius = 50
        filter_order = 2
        # 计算每个频率点距离中心的距离
        u, v = np.meshgrid(np.arange(width), np.arange(height))
        du = u - width // 2
        dv = v - height // 2
        distance = np.sqrt(du ** 2 + dv ** 2)
        # 巴特沃斯低通掩膜
        butterworth_mask = 1 / (1 + (distance / cutoff_radius) ** (2 * filter_order))
        fft_image = np.fft.fft2(gray)
        fft_shifted = np.fft.fftshift(fft_image)
        filtered = fft_shifted * butterworth_mask
        inverse_shifted = np.fft.ifftshift(filtered)
        spatial_image = np.fft.ifft2(inverse_shifted)
        img_result = np.abs(spatial_image)
        img_result = np.uint8(np.clip(img_result, 0, 255))
        qt_img = CvimgtoQtimg(img_result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def GaussianLow(self):
        """ 高斯低通滤波器 """
        if self.Check():
            return
        gray = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        height, width = gray.shape
        cutoff_radius = 50
        u, v = np.meshgrid(np.arange(width), np.arange(height))
        du = u - width // 2
        dv = v - height // 2
        distance = np.sqrt(du ** 2 + dv ** 2)
        # 高斯低通掩膜
        gaussian_mask = np.exp(-(distance ** 2) / (2 * (cutoff_radius ** 2)))
        fft_image = np.fft.fft2(gray)
        fft_shifted = np.fft.fftshift(fft_image)
        filtered = fft_shifted * gaussian_mask
        inverse_shifted = np.fft.ifftshift(filtered)
        spatial_image = np.fft.ifft2(inverse_shifted)
        img_result = np.abs(spatial_image)
        img_result = np.uint8(np.clip(img_result, 0, 255))

        qt_img = CvimgtoQtimg(img_result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def IdealHigh(self):
        """ 理想高通滤波器：去除低频，保留高频 """
        if self.Check():
            return
        gray = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        fft_image = np.fft.fft2(gray)
        fft_shifted = np.fft.fftshift(fft_image)
        height, width = gray.shape
        center_u, center_v = height // 2, width // 2
        cutoff_radius = 25
        # 理想高通掩膜：中心置0，周围为1
        highpass_mask = np.ones((height, width), np.uint8)
        highpass_mask[center_u - cutoff_radius:center_u + cutoff_radius,
        center_v - cutoff_radius:center_v + cutoff_radius] = 0
        filtered = fft_shifted * highpass_mask
        inverse_shifted = np.fft.ifftshift(filtered)
        spatial_image = np.fft.ifft2(inverse_shifted)
        img_result = np.abs(spatial_image)
        img_result = np.uint8(np.clip(img_result, 0, 255))
        qt_img = CvimgtoQtimg(img_result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def ButterworthHigh(self):
        """ 巴特沃斯高通滤波器 """
        if self.Check():
            return
        gray = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        height, width = gray.shape
        cutoff_radius = 50
        filter_order = 2
        u, v = np.meshgrid(np.arange(width), np.arange(height))
        du = u - width // 2
        dv = v - height // 2
        distance = np.sqrt(du ** 2 + dv ** 2)
        # 巴特沃斯高通掩膜
        butterworth_mask = 1 / (1 + (cutoff_radius / (distance + 1e-5)) ** (2 * filter_order))
        fft_image = np.fft.fft2(gray)
        fft_shifted = np.fft.fftshift(fft_image)
        filtered = fft_shifted * butterworth_mask
        inverse_shifted = np.fft.ifftshift(filtered)
        spatial_image = np.fft.ifft2(inverse_shifted)
        img_result = np.abs(spatial_image)
        img_result = np.uint8(np.clip(img_result, 0, 255))
        qt_img = CvimgtoQtimg(img_result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def GaussianHigh(self):
        """ 高斯高通滤波器：基于高斯函数抑制低频，突出边缘 """
        if self.Check():
            return
        gray = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        height, width = gray.shape
        cutoff_radius = 50
        u, v = np.meshgrid(np.arange(width), np.arange(height))
        du = u - width // 2
        dv = v - height // 2
        distance = np.sqrt(du ** 2 + dv ** 2)
        # 高斯高通掩膜 = 1 - 高斯低通掩膜
        gaussian_mask = 1 - np.exp(-(distance ** 2) / (2 * (cutoff_radius ** 2)))
        fft_image = np.fft.fft2(gray)
        fft_shifted = np.fft.fftshift(fft_image)
        filtered = fft_shifted * gaussian_mask
        inverse_shifted = np.fft.ifftshift(filtered)
        spatial_image = np.fft.ifft2(inverse_shifted)
        img_result = np.abs(spatial_image)
        img_result = np.uint8(np.clip(img_result, 0, 255))
        qt_img = CvimgtoQtimg(img_result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def SpatialSharpening(self):
        """ 空间域锐化处理：使用拉普拉斯增强边缘 """
        if self.Check():
            return
        gray = cv2.cvtColor(self.image, cv2.COLOR_RGB2GRAY)
        # 拉普拉斯算子提取边缘
        laplacian = cv2.Laplacian(gray, cv2.CV_16S, ksize=3)
        laplacian = cv2.convertScaleAbs(laplacian)  # 转换为8位
        # 融合原图和边缘图像
        img_result = cv2.addWeighted(gray, 1.0, laplacian, 1.0, 0)
        qt_img = CvimgtoQtimg(img_result)
        self.pix_after = QPixmap.fromImage(qt_img)
        self.ResizeImage(self.pic_after, self.pix_after)

    def Style_transfer(self):
        """ 使用外部脚本执行图像风格迁移 """
        print("输入检查通过，开始准备执行风格迁移...")
        script_path = "./pytorch-neural-style-transfer/neural_style_transfer.py"
        style_weight_input = self.StyleEdit.text().strip()
        content_weight_input = self.ContentEdit.text().strip()
        if not style_weight_input or not content_weight_input:
            print("错误：风格权重和内容权重不能为空！请在界面中填写数值。")
            return
        try:
            float(style_weight_input)
            float(content_weight_input)
        except ValueError:
            print("错误：权重参数必须为合法的数字（浮点数）！")
            return
        # 设定命令行参数，输入脚本中执行命令
        command = [
            "python", script_path,
            "--content_img_name", self.openfile_name,
            "--style_img_name", self.openfile_name3,
            "--style_weight", style_weight_input,
            "--content_weight", content_weight_input
        ]
        print("正在执行命令...")
        print(f"命令: {' '.join(command)}")
        try:
            process = subprocess.run(
                command,
                check=True,
                capture_output=True,
                text=True,
                encoding='utf-8',
                timeout=600
            )
            print("--- 风格迁移脚本输出 (stdout) ---")
            print(process.stdout)
            print("---------------------------------")
        except subprocess.TimeoutExpired:
            print("错误：风格迁移进程超时（超过10分钟）")
        except subprocess.CalledProcessError as e:
            print("错误：风格迁移脚本执行失败")
            print(f"退出码: {e.returncode}")
            print("--- stdout ---")
            print(e.stdout)
            print("--- stderr ---")
            print(e.stderr)
        except FileNotFoundError:
            print("错误: 未找到 'python' 命令。请检查环境变量")

if __name__ == "__main__":
    cap = cv2.VideoCapture(0)  # 启动摄像头
    app = QtWidgets.QApplication(sys.argv)  # 创建应用对象
    main_window = myWindow()  # 创建主窗口
    main_window.show()  # 显示窗口
    sys.exit(app.exec_())
